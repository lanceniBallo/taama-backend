const express = require('express');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const { splitAmount } = require('../utils/finance');

const router = express.Router();

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Non authentifié' });
  try { req.user = jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Token invalide' }); }
}

router.get('/', requireAuth, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT b.*, l.title, l.subtitle, l.icon, l.accent_color
       FROM bookings b JOIN listings l ON l.id=b.listing_id
       WHERE b.user_id=$1 ORDER BY b.created_at DESC`, [req.user.userId]
    );
    res.json(rows);
  } catch (err) { console.error(err.message); res.status(500).json({ error:'Erreur serveur' }); }
});

router.post('/', requireAuth, async (req, res) => {
  const { listing_id, payment_method, passenger_name, passenger_document, contact_phone, contact_email, options } = req.body;
  try {
    const { rows } = await pool.query(
      `SELECT l.*, p.id AS partner_id FROM listings l LEFT JOIN partners p ON p.id=l.partner_id WHERE l.id=$1 AND l.is_active=TRUE`, [listing_id]
    );
    const listing = rows[0];
    if (!listing) return res.status(404).json({ error:'Offre introuvable ou inactive' });
    if (!Number.isInteger(Number(listing.price_fcfa)) || Number(listing.price_fcfa)<0) return res.status(400).json({ error:'Prix invalide' });

    const { rate, commission, partnerAmount } = splitAmount(listing.price_fcfa, listing.type);
    const reference = 'TM-' + Math.random().toString(36).slice(2,8).toUpperCase();
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const inserted = await client.query(
        `INSERT INTO bookings
          (reference,user_id,listing_id,status,price_fcfa,payment_method,passenger_name,passenger_document,contact_phone,contact_email,options,commission_rate,commission_fcfa,partner_amount_fcfa)
         VALUES ($1,$2,$3,'En attente',$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
        [reference,req.user.userId,listing_id,listing.price_fcfa,payment_method||'manuel',passenger_name||null,passenger_document||null,contact_phone||null,contact_email||null,options||{},rate,commission,partnerAmount]
      );
      await client.query(
        `INSERT INTO financial_ledger (booking_id,partner_id,kind,amount_fcfa,description)
         VALUES ($1,$2,'booking_pending',$3,$4)`,
        [inserted.rows[0].id, listing.partner_id, listing.price_fcfa, `Réservation ${reference}`]
      );
      await client.query('COMMIT');
      res.status(201).json(inserted.rows[0]);
    } catch (err) { await client.query('ROLLBACK'); throw err; }
    finally { client.release(); }
  } catch (err) { console.error('create booking:',err.message); res.status(500).json({error:'Erreur serveur'}); }
});

// À appeler uniquement par un webhook de paiement authentifié en production.
router.patch('/:id/confirm', async (req,res) => {
  if (process.env.PAYMENT_WEBHOOK_SECRET && req.headers['x-payment-webhook-secret'] !== process.env.PAYMENT_WEBHOOK_SECRET) {
    return res.status(401).json({error:'Webhook non autorisé'});
  }
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const {rows}=await client.query(`UPDATE bookings SET status='Confirmé', payment_status='payé', paid_at=now() WHERE id=$1 AND status<>'Confirmé' RETURNING *`,[req.params.id]);
    if(!rows[0]){await client.query('ROLLBACK');return res.status(404).json({error:'Réservation introuvable ou déjà confirmée'});}
    await client.query(`INSERT INTO financial_ledger (booking_id,partner_id,kind,amount_fcfa,description)
      SELECT b.id,l.partner_id,'booking_paid',b.price_fcfa,'Paiement confirmé '||b.reference FROM bookings b JOIN listings l ON l.id=b.listing_id WHERE b.id=$1`,[req.params.id]);
    await client.query('COMMIT'); res.json(rows[0]);
  }catch(err){await client.query('ROLLBACK');console.error('confirm booking:',err.message);res.status(500).json({error:'Erreur serveur'});}finally{client.release();}
});

module.exports=router;
