const express = require('express');
const pool = require('../db');
const { COMMISSION_RATES } = require('../utils/finance');

const router = express.Router();

function requireAdmin(req, res, next) {
  const key = req.headers['x-admin-key'];
  if (!key || key !== process.env.ADMIN_KEY) return res.status(401).json({ error: 'Non autorisé' });
  next();
}

// Vue financière globale pour Taama Admin.
router.get('/summary', requireAdmin, async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        COALESCE(SUM(CASE WHEN status <> 'Annulé' THEN price_fcfa ELSE 0 END),0)::int AS gross_fcfa,
        COALESCE(SUM(CASE WHEN status <> 'Annulé' THEN commission_fcfa ELSE 0 END),0)::int AS commission_fcfa,
        COALESCE(SUM(CASE WHEN status <> 'Annulé' THEN partner_amount_fcfa ELSE 0 END),0)::int AS partner_fcfa,
        COUNT(*)::int AS booking_count
      FROM bookings
    `);
    const withdrawals = await pool.query(`
      SELECT
        COALESCE(SUM(CASE WHEN status='En attente' THEN amount_fcfa ELSE 0 END),0)::int AS pending_fcfa,
        COALESCE(SUM(CASE WHEN status='Payé' THEN amount_fcfa ELSE 0 END),0)::int AS paid_fcfa
      FROM partner_withdrawals
    `);
    res.json({ ...rows[0], ...withdrawals.rows[0], commission_rates: COMMISSION_RATES });
  } catch (err) {
    console.error('finance summary:', err.message);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

router.get('/withdrawals', requireAdmin, async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT w.*, p.name AS partner_name
      FROM partner_withdrawals w
      JOIN partners p ON p.id = w.partner_id
      ORDER BY w.created_at DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error('finance withdrawals:', err.message);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

router.patch('/withdrawals/:id/pay', requireAdmin, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `UPDATE partner_withdrawals
       SET status='Payé', processed_at=now()
       WHERE id=$1 AND status='En attente'
       RETURNING *`, [req.params.id]
    );
    if (!rows[0]) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Retrait introuvable ou déjà traité' });
    }
    await client.query(
      `INSERT INTO financial_ledger (partner_id, kind, amount_fcfa, description)
       VALUES ($1,'withdrawal',-$2,$3)`,
      [rows[0].partner_id, rows[0].amount_fcfa, `Retrait ${rows[0].id}`]
    );
    await client.query('COMMIT');
    res.json(rows[0]);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('pay withdrawal:', err.message);
    res.status(500).json({ error: 'Erreur serveur' });
  } finally { client.release(); }
});

router.post('/withdrawals/:id/reject', requireAdmin, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `UPDATE partner_withdrawals SET status='Rejeté', processed_at=now(), note=$2
       WHERE id=$1 AND status='En attente' RETURNING *`,
      [req.params.id, req.body?.note || null]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Retrait introuvable ou déjà traité' });
    res.json(rows[0]);
  } catch (err) {
    console.error('reject withdrawal:', err.message);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

router.get('/partners/:id', requireAdmin, async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        p.id, p.name, p.type, p.is_active,
        COALESCE(SUM(CASE WHEN b.status <> 'Annulé' THEN b.price_fcfa ELSE 0 END),0)::int AS gross_fcfa,
        COALESCE(SUM(CASE WHEN b.status <> 'Annulé' THEN b.commission_fcfa ELSE 0 END),0)::int AS commission_fcfa,
        COALESCE(SUM(CASE WHEN b.status <> 'Annulé' THEN b.partner_amount_fcfa ELSE 0 END),0)::int
          - COALESCE((SELECT SUM(amount_fcfa) FROM partner_withdrawals w WHERE w.partner_id=p.id AND w.status='Payé'),0)::int AS available_fcfa
      FROM partners p
      LEFT JOIN listings l ON l.partner_id=p.id
      LEFT JOIN bookings b ON b.listing_id=l.id
      WHERE p.id=$1
      GROUP BY p.id
    `, [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'Partenaire introuvable' });
    res.json(rows[0]);
  } catch (err) {
    console.error('partner finance:', err.message);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
